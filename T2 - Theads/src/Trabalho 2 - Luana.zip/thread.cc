#include "thread.h"

__BEGIN_API


int Thread::switch_context(Thread * prev, Thread * next){
	if(prev && next){
	CPU::switch_context(prev->_context, next->_context);
	return 1;
	} 
	else return 0;
}


void Thread::thread_exit (int exit_code){
	
	delete _context;
//	delete _running;
}

int Thread::id(){
	return _id;
}


__END_API
