#include "cpu.h"
#include <iostream>

__BEGIN_API

void CPU::Context::save()

{
	setcontext(&_context);
}

void CPU::Context::load()
{
	getcontext(&_context);
	
}

CPU::Context::~Context()
{	
/*
	free (_context.uc_stack.ss_sp);
	delete _stack;
	free (_context.uc_link);
	delete this;
*/
    //adicionar implementação
   //delete na pilha
}

void CPU::switch_context(Context *from, Context *to)
{
     	swapcontext(&(from->_context), &(to->_context));
}


__END_API
